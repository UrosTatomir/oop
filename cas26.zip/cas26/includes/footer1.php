</div>
<!--end container fluid-->
<footer class=" bg-dark fixed-bottom">
    <div class="container text-center">
        
        <p><a class="text-white" href="#">Copyright by PHP DEVLOPERS 2019</a></p>

    </div>
</footer>
</body>

</html> 