</div> <!-- end container fluid-->
<div class="card text-center">
    <div class="card-header" style="background-color:#E7F5C0;">
        <ul class="nav nav-pills card-header-pills">
            <li class="nav-item">
                <a class="nav-link active" href="#">Active</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Link</a>
            </li>
            <li class="nav-item">
                <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true">Disabled</a>
            </li>
        </ul>
    </div>
    <div class="card-body">
        <div class="row no-gutters">
            <div class="col-md-3">
                <h5 class="card-title" style="font-family: cursive, sans-serif; color: #2A65CB; font-size:22px;">CarsAndFreeRoads</h5>
                <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                <a href="#" class="btn btn-primary">Go somewhere</a>
            </div>
            <div class="col-md-3">
                <h5 class="card-title">Useful links</h5>
                <p>
                    <a class="dark-grey-text" href="#">Admin</a>
                </p>
                <p>
                    <a class="dark-grey-text" href="#">Login</a>
                </p>
                <p>
                    <a class="dark-grey-text" href="#">Logout</a>
                </p>
            </div>
            <div class="col-md-3">
                <h5 class="card-title">Social networks links</h5>

                <p><a href="https://www.facebook.com/bootsnipp"><i class="fa fa-facebook-official fa-2x">facebook.com</i>
                    </a></p>
                <!-- Twitter -->
                <p><a href="https://twitter.com/bootsnipp" class="tw-ic">
                        <i class="fa fa-twitter white-text fa-2x">twitter.com</i>
                    </a></p>
                <p><a href="https://www.instagram.com" class="ins-ic">
                        <i class="fa fa-instagram white-text fa-2x">instagram.com </i>
                    </a></p>
            </div>
            <div class="col-md-3">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d44046.34778673461!2d20.373595703090647!3d44.81842912563373!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x6ac98796b9b4098e!2sEstavela!5e0!3m2!1ssr!2srs!4v1540830623478" width="170" height="170" frameborder="0" style="border:0" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</div>
</body>

</html> 