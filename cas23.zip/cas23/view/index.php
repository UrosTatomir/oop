<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
    
    <h3><a href="routes.php?page=showinsert">Insert Car</a></h3>

   <h3> <a href="routes.php?page=showinsertvozaca">Insert Driver</a></h3>
    
    <h3><a href="routes.php?page=showassign">Assigning a vehicle to the driver</a></h3> 

    <h3><a href="routes.php?page=showdrivers">Show Drivers</a></h3> 

    <h3><a href="routes.php?page=showcars">Show Cars</a></h3>

    <h3><a href="routes.php?page=showdriverbycars">Show driver by cars</a></h3> 

    <h3><a href="routes.php?page=showcarbydrivers">Show car by drivers</a></h3> 
    

</body>
</html>